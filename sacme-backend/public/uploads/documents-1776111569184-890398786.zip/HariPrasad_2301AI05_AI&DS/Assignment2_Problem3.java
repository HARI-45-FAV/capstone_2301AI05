class Student {

    protected int units;

    public Student(int units) {
        this.units = units;
    }

    public int getUnits() {
        return units;
    }

    public int getStress() {
        return units * 10;
    }
}

class Grad extends Student {

    private int yearsOnThesis;

    public Grad() {
        this(10, 0);
    }

    public Grad(int units, int yearsOnThesis) {
        super(units);
        this.yearsOnThesis = yearsOnThesis;
    }

    @Override
    public int getStress() {
        return 2 * super.getStress() + yearsOnThesis;
    }
}

public class Assignment2_Problem3 {

    public static void main(String[] args) {

        Grad g1 = new Grad();
        System.out.println("Test1: " + g1.getUnits());

        System.out.println("Test2: " + g1.getStress());

        Grad g2 = new Grad(15, 2);
        System.out.println("Test3: " + g2.getUnits());

        System.out.println("Test4: " + g2.getStress());

        Student s = g2;
        System.out.println("Test5: " + s.getStress());
    }
}