class Student {

    protected int units;

    public Student(int units) {
        this.units = units;
    }

    public int getUnits() {
        return units;
    }

    public int getStress() {
        return units * 10;
    }
}

class Grad extends Student {

    private int yearsOnThesis;

    public Grad(int units, int yearsOnThesis) {
        super(units);
        this.yearsOnThesis = yearsOnThesis;
    }

    @Override
    public int getStress() {
        return 2 * super.getStress() + yearsOnThesis;
    }

    public int getYearsOnThesis() {
        return yearsOnThesis;
    }
}

public class Assignment2_Problem2 {

    public static void main(String[] args) {

        Student s = new Grad(12, 3);
        System.out.println("Test1: " + s.getStress());

        if (s instanceof Grad) {
            Grad g = (Grad) s;
            System.out.println("Test2: " + g.getYearsOnThesis());
        }

        Student s2 = new Student(8);
        System.out.println("Test3: " + s2.getStress());

        System.out.println("Test4: " + (s2 instanceof Grad));

        System.out.println("Test5: " + (s instanceof Student));
    }
}