abstract class Account {

    protected double balance;
    protected int transactionCount;

    public Account(double balance) {
        this.balance = balance;
        this.transactionCount = 0;
    }

    public void deposit(double amount) {
        balance += amount;
        transactionCount++;
    }

    public void withdraw(double amount) {
        balance -= amount;
        transactionCount++;
    }

    public void endMonth() {
        balance -= endMonthCharge();
        transactionCount = 0;
    }

    abstract double endMonthCharge();
}

class NormalAccount extends Account {

    public NormalAccount(double balance) {
        super(balance);
    }

    @Override
    double endMonthCharge() {
        return 5.0;
    }
}

public class Assignment2_Problem5 {

    public static void main(String[] args) {

        Account acc = new NormalAccount(100);

        acc.deposit(50);
        acc.withdraw(20);
        System.out.println("Test1: " + acc.balance);

        acc.endMonth();
        System.out.println("Test2: " + acc.balance);

        acc.deposit(25);
        System.out.println("Test3: " + acc.balance);

        acc.endMonth();
        System.out.println("Test4: " + acc.balance);

        System.out.println("Test5: " + (acc instanceof Account));
    }
}