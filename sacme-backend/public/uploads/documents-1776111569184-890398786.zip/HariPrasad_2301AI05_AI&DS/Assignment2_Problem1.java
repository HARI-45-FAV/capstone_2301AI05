class Student {
    protected int units;

    public Student(int units) {
        this.units = units;
    }

    public int getUnits() {
        return units;
    }

    public int getStress() {
        return units * 10;
    }
}

class Grad extends Student {
    private int yearsOnThesis;

    public Grad(int units, int yearsOnThesis) {
        super(units);
        this.yearsOnThesis = yearsOnThesis;
    }

    @Override
    public int getStress() {
        return 2 * super.getStress() + yearsOnThesis;
    }
}

public class Assignment2_Problem1 {
    public static void main(String[] args) {
        Student s1 = new Student(10);
        System.out.println("Test1 : " + s1.getStress());

        Grad g1 = new Grad(10, 2);
        System.out.println("Test2 : " + g1.getStress());

        Student s2 = new Grad(15, 3);
        System.out.println("Test3 : " + s2.getStress());

        System.out.println("Test4 : " + g1.getUnits());

        Grad g2 = new Grad(20, 5);
        System.out.println("Test5 : " + g2.getStress());
    }
}