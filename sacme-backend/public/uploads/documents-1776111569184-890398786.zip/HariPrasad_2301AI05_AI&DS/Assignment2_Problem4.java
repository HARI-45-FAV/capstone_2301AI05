interface Moodable {

    String getMood();
}

class Student implements Moodable {

    protected int units;

    public Student(int units) {
        this.units = units;
    }

    public int getStress() {
        return units * 10;
    }

    @Override
    public String getMood() {

        if (getStress() > 100)
            return "Angry";
        else
            return "Calm";
    }
}

class Grad extends Student {

    private int yearsOnThesis;

    public Grad(int units, int yearsOnThesis) {
        super(units);
        this.yearsOnThesis = yearsOnThesis;
    }

    @Override
    public int getStress() {
        return 2 * super.getStress() + yearsOnThesis;
    }
}

public class Assignment2_Problem4 {

    public static void main(String[] args) {

        Student s1 = new Student(8);
        System.out.println("Test1: " + s1.getMood());

        Student s2 = new Student(15);
        System.out.println("Test2: " + s2.getMood());

        Moodable m = s2;
        System.out.println("Test3: " + m.getMood());

        Grad g = new Grad(12, 2);
        System.out.println("Test4: " + g.getMood());

        System.out.println("Test5: " + (g instanceof Moodable));
    }
}